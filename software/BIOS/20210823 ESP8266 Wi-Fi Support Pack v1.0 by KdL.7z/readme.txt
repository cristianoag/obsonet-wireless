ESP8266 Wi-Fi Support Pack v1.0
===============================

Author:  KdL
Update:  2021.08.23

This package includes the latest "ESP8266 UNAPI Firmware by ducasp" and some support instructions.
Please read the license here: http://github.com/ducasp/ESP8266-UNAPI-Firmware/blob/master/LICENSE

The use of a specific Wi-Fi module is governed by the laws of your country under your responsibility.
The author disclaims any liability for the misuse of the contents of this package.


______
Enjoy!
